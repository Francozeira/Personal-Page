<?php

	session_start();  
	
	require_once('db.class.php');
	
	$user = $_POST['find_form'];
	$user_id = $_SESSION['id_usuario'];
	
	$obj_db = new db;
	$link = $obj_db->db_connect();
	
	// $sql = "select * from usuarios where usuario like '%$user%' AND id <> '$user_id'";
	$sql = "SELECT u.* , s.* ";
	$sql.= "FROM usuarios AS u ";
	$sql.= "LEFT JOIN user_followers AS s ";
	$sql.= "ON ( s.id_usuario = '$user_id' AND u.id = s.id_usuario_seguindo ) ";
	$sql.= "WHERE u.usuario like '%$user%' AND u.id <> '$user_id'";

	$result_id = mysqli_query($link,$sql);
	
	if($result_id){
		
		while($registro = mysqli_fetch_array($result_id)){
			echo'<a href="#" class="list-group-item clearfix">';
				echo'<strong>'.$registro['usuario'].'</strong><small> '.$registro['email'].' </small>';
						
				echo'<p class="list-group-item-text	pull-right">';
				
					$follower_boolean_checker = isset($registro['id_usuario_seguidor']) && !empty($registro['id_usuario_seguidor'])? 'S' : 'N';
					$display_follow_btn = 'block';
					$display_unfollow_btn = 'block';
					
					if($follower_boolean_checker == 'N'){
						
						$display_unfollow_btn = 'none';
						
					} else {
						
						$display_follow_btn = 'none';

					}
					
					echo'<button 
						id="btn_follow_'.$registro['id'].'"
						class="btn btn-info btn_follow"
						style="display: '.$display_follow_btn.'"
						data-id_usuario = "'.$registro['id'].'">
						Follow</button>';
						
					echo'<button 
						id="btn_unfollow_'.$registro['id'].'"
						style="display: '.$display_unfollow_btn.'" 
						class="btn btn-danger btn_unfollow" 
						data-id_usuario = "'.$registro['id'].'">
						Unfollow</button>';
				echo'</p>';
			echo'</a>';
		}
		
	}else echo 'Erro na consulta de usuários'
?>
