<?php

require_once('db.class.php');

$sql = "select * FROM usuarios";

$obj_db = new db();
$link = $obj_db->db_connect();

$result_id = mysqli_query($link,$sql);

if($result_id){
	
	$user_data = array();
	while($linha = mysqli_fetch_array($result_id,MYSQLI_ASSOC)){
		$user_data[] = $linha;
	}
	
	foreach($user_data as $user){
		var_dump($user);
		echo '<br><br>';
	}

} else echo'System failure, blame dev!';	

?>