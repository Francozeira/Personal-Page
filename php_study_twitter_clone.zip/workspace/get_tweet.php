<?php

	session_start();
	
	if(!isset($_SESSION['usuario'])){
		header('Location: index.php?error=1');
	}
	
	require_once('db.class.php');
	
	$texto_tweet = $_POST['texto_tweet'];
	$user_id = $_SESSION['id_usuario'];
	
	
	$obj_db = new db;
	$link = $obj_db->db_connect();
	
	$sql = "select date_format(t.inclusion_date,'%d %b %Y %T') as format_data , t.tweet, u.usuario from tweet as t join usuarios as u on (t.user_id = u.id)";
	$sql .= "where user_id = $user_id ";
	$sql .= "OR user_id IN (SELECT id_usuario_seguindo FROM user_followers WHERE id_usuario = $user_id) ";
	$sql .= "order by inclusion_date desc ";
	$result_id = mysqli_query($link,$sql);
	
	if($result_id){
		
		while($registro = mysqli_fetch_array($result_id)){
			echo'<a href="#" class="list-group-item">';
				echo'<h4 class="list-group-item-heading"> '.$registro['usuario'].' <small> - '.$registro['format_data'].'</small> </h4>';
				echo'<p class="list-group-item-text"> '.$registro['tweet'].'</p>';
			echo'</a>';

		}
		
	}else echo 'Erro na consulta'
?>
