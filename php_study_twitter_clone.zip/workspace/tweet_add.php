<?php

	session_start();
	
	if(!isset($_SESSION['usuario'])){
		header('Location: index.php?error=1');
	}
	
	require_once('db.class.php');
	
	$texto_tweet = $_POST['texto_tweet'];
	$user_id = $_SESSION['id_usuario'];
	
	if($texto_tweet =='' && $user_id ==''){
		die();
	}
	
	$obj_db = new db;
	$link = $obj_db->db_connect();
	
	$sql = "insert into tweet (user_id,tweet,inclusion_date)values('$user_id','$texto_tweet', now()) ";
	mysqli_query($link,$sql);
	
?>
