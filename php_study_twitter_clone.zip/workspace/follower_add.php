<?php

	session_start();
	
	if(!isset($_SESSION['usuario'])){
		header('Location: index.php?error=1');
	}
	
	require_once('db.class.php');
	
	$user_id = $_SESSION['id_usuario'];
	$user_id_follow = $_POST['user_id_follow'];
	
	if($user_id =='' || $user_id_follow ==''){
		die();
	}
	
	$obj_db = new db;
	$link = $obj_db->db_connect();
	
	$sql = "insert into user_followers (id_usuario,id_usuario_seguindo,data_registro)";
	$sql.= "values($user_id,$user_id_follow, now()) ";
	
	mysqli_query($link,$sql);
	
?>
