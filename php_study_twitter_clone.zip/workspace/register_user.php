<?php

	require_once('db.class.php');
	
	$usuario = ($_POST['usuario']);
	$email = ($_POST['email']);
	$senha = md5($_POST['senha']);
	
	$obj_db = new db();
	$link = $obj_db->db_connect();
	
	$user_exists = false;
	$email_exists = false;
	
	// VERIFICAÇÃO DO USUÁRIO
	$sql = "select * from usuarios where usuario = '$usuario'";
	if($result_id = mysqli_query($link,$sql)){
		$user_data = mysqli_fetch_array($result_id);

		if(isset($user_data['usuario'])){
			
			$user_exists = true;
			
		}
		
	} else {
		
		echo 'User localization error';
	}
	
	// VERIFICAÇÃO DA SENHA
	$sql = "select * from usuarios where email = '$email'";
	if($result_id = mysqli_query($link,$sql)){
		$user_data = mysqli_fetch_array($result_id);

		if(isset($user_data['email'])){
			
			$email_exists = true;

		} 
	} else {
		echo 'Email localization error';
	}
	
	// RETORNO A TELA DE INSCRIÇÃO
	if($user_exists || $email_exists){
		$get_return = '';
		
		if($user_exists){
			$get_return.= "user_error=1&";
		}
				
		if($email_exists){
			$get_return.= "email_error=1&";
		}
		
		header('Location: inscrevase.php?'.$get_return);
		die();
	}
	
	// DEFINIÇÃO DA QUERY
	$sql = "insert into usuarios(usuario,email,senha) values('$usuario','$email','$senha')";
	if(!mysqli_query($link,$sql)){
		echo 'Error sign in user';
	} 
?>

<!DOCTYPE HTML>
<html lang="pt-br">
	<head>
		<meta charset="UTF-8">

		<title>User Signed in</title>
		
		<!-- jquery - link cdn -->
		<script src="https://code.jquery.com/jquery-2.2.4.min.js"></script>

		<!-- bootstrap - link cdn -->
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
	
	</head>

	<body>

		<!-- Static navbar -->
	    <nav class="navbar navbar-default navbar-static-top">
	      <div class="container">
	        <div class="navbar-header">
	          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
	            <span class="sr-only">Toggle navigation</span>
	            <span class="icon-bar"></span>
	            <span class="icon-bar"></span>
	            <span class="icon-bar"></span>
	          </button>
	          <img src="img/icone_twitter.png" style="margin-top: 5px" />
	        </div>
	        
	        <div id="navbar" class="navbar-collapse collapse">
	          <ul class="nav navbar-nav navbar-right">
	            <li><a href="index.php">Return Home</a></li>
	          </ul>
	        </div><!--/.nav-collapse -->
	      </div>
	    </nav>


	    <div class="container">
	    	
	    	<br /><br />

	    	<div class="col-md-6 col-md-offset-3 text center">
	    		<h1>User registered sucessfully!</h1>
			</div>
	    </div>
	
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
	
	</body>
</html>