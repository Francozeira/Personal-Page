<?php

	session_start();
	
	if(!isset($_SESSION['usuario'])){
		header('Location: index.php?error=1');
	}
	
	require_once('db.class.php');
	
	$user_id = $_SESSION['id_usuario'];
	$user_id_unfollow = $_POST['user_id_unfollow'];
	
	if($user_id =='' || $user_id_unfollow ==''){
		die();
	}
	
	$obj_db = new db;
	$link = $obj_db->db_connect();
	
	$sql = "delete from user_followers where id_usuario = $user_id AND id_usuario_seguindo = $user_id_unfollow";

	mysqli_query($link,$sql);
	
?>
