<?php
	class db{
		
	    private $host = "127.0.0.1";
		private $user = "mgoes";                     //Your Cloud 9 username
	    private $pass = "";                                  //Remember, there is NO password by default!
	    private $db = "twitter_clone";                                  //Your database name you want to connect to
	    private $port = 3306;

	
		function db_connect(){
			$con = mysqli_connect($this->host,$this->user,$this->pass,$this->db);
			mysqli_set_charset($con,'utf8');
			
			if(mysqli_connect_errno()){
				echo 'erro: '.mysqli_connect_error();
			}
			return $con;
		}
	
	}	
?>