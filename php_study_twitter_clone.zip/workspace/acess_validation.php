<?php

session_start();

require_once('db.class.php');

$usuario = $_POST['usuario'];
$senha = md5($_POST['senha']);

$sql = "select id,usuario, email from usuarios where usuario = '$usuario' AND senha = '$senha'";

$obj_db = new db();
$link = $obj_db->db_connect();

$result_id = mysqli_query($link,$sql);

if($result_id){
	
	$user_data = mysqli_fetch_array($result_id);
	if(isset ($user_data['usuario'])){
		
		$_SESSION['id_usuario'] = $user_data['id'];
		$_SESSION['usuario'] = $user_data['usuario'];
		$_SESSION['email'] = $user_data['email'];


		header('Location: home.php');
		
	} else{
		
		header('Location: index.php?error=1');
		
	}
	
} else{
	
	echo'System failure, blame dev!';	
	
}



?>